# Agent Record

Validated records, research reports, adapters, and command-line ingest/export for recorded agent work. React views live in [Sandbox UI](https://github.com/tangle-network/sandbox-ui); chart geometry and playback live in [Charts](https://github.com/tangle-network/charts).

## Install

```sh
pnpm add "$(gh release view --repo drewstone/agent-record --json assets --jq '.assets[] | select(.name | endswith(".tgz")) | .url')"
```

The ESM package and TypeScript declarations are distributed through GitHub Releases. This package is not published to npm. Use an immutable release asset when pinning a consumer.

### Release a package

Merge a stable `major.minor.patch` version bump in `package.json` to `main`. The **Publish package** workflow qualifies that exact commit on the existing Beelink runners with a frozen install, native build, typecheck, tests and pack. Its separate publishing job creates the matching `v<version>` tag and a draft release, uploads the package and its SHA256 file, verifies both assets, then publishes. Only that job receives repository write permission. Retry an interrupted release by rerunning its original workflow run so its source commit stays fixed. Manual dispatch also works while `main` still names that commit.

A retry accepts an existing published version only when its tag and both asset digests match. It can finish a matching draft, but never replaces a tag or asset; a collision requires a new version. Consumers pin the versioned `.tgz` URL and verify its SHA256 before updating their lockfile and qualifying the installed package. Version 3.0.8 retains execution phase/finality and unknown holder liveness; consumers must handle `execution.alive` as `boolean | null`.

The repository's dependency policy keeps the one-day release-age check for external dependencies. Only `@tangle-network/*` and `@drewstone/agent-record` are exempt, so qualified first-party releases can be consumed immediately. Frozen lockfile integrity checks still apply to every dependency.

```ts
import { parseRecord } from '@drewstone/agent-record/record'

const record = parseRecord(await response.json())
```

`agent-record.v1` contains a run ID, nodes, and timestamped events. Parsing preserves metadata and rejects duplicate identities, invalid timestamps, parent cycles, invalid session joins, and duplicate call IDs within an event. Missing capture, unresolved parents, and unknown measurements remain explicit; a recorded zero stays zero. See [the record format](docs/record-format.md).

## Retained views

```tsx
import { AgentRecord, RecordWorkGraph } from '@tangle-network/sandbox-ui/record'
import '@tangle-network/sandbox-ui/styles'

export function RunPage({ record }) {
  return <><AgentRecord records={[record]} /><RecordWorkGraph record={record} /></>
}
```

Sandbox UI owns the retained record view, authored report views, and evidence graph. Hosts supply validated records and control selection/URLs. Charts owns the run timeline. Renderers preserve original event/call identities and never infer missing captures or relationships from names or timing.

### The record as a story

```ts
import { recordStory, utc, span } from '@drewstone/agent-record/story'
```

Every value a record view prints comes from here, so every host shows the same numbers. The story reads only the record's own fields: node identity, `parent`, the `agentId` join and `capture`; each event's `category`, tool calls and their results (paired by node and call id), `durationMs` and `atBasis`; `usage` and `costListUsd` with their scope; inputs (`role: 'user'`) and their structured `check`; `claims` and recorded findings. It parses no producer's tool names or text conventions.

`recordStory(record)` computes the story once per record. Its `summary` gives the title, what was asked, the run's answer in its own words (the last recorded claim, finding or check, else the root agent's last words, with who said it and when), the result in order (an outside check's verdict unless it gave that answer, then how the run ended), one sentence per agent of what it did (for an agent with nothing captured, why), cost and output tokens per agent and in total, and what the record leaves out. An agent's spend is its most complete source, never a sum of sources (see `usageScope` in the [record format](docs/record-format.md)). Its `steps` merge a model turn with each tool call it made and say what ran: the command, file, query or address from its arguments, with its input, output, outcome and recorded duration. `episodes` group steps into aims (split by narration, inputs, idle gaps over 3 min and long-call chains) and fold runs of identical unpublished steps; a partly captured agent's silence of 10 min or more is its own row. `turningPoints` keep real moments only, at most sixteen: the start, spawns, agents with no captured steps, new prompts and checks, findings, the result, endings and the run's end; failed steps stay on their steps and episodes. An episode's title is someone's own sentence (the input that opened it, else the agent's first words), else what its steps acted on. `utc` and `span` format every time and length. A missing value is omitted, never printed as 0, a dash or "Unknown".

The graph model remains available from this package’s `/record` entry. It links only recorded parent IDs, source hashes, claim IDs, reviewer sessions, citations, and profile digests. Missing targets remain unlinked.

Version3 retires this package’s React view exports and stylesheet; import their maintained owners above. Version2 retires Discovery workspace/page exports, its browser bundle, and standalone receipt renderer. Discovery composition lives in the [Tools viewer](https://github.com/drewstone/tangle-tools/tree/main/fleet/discovery_workspace_parts/viewer). Immutable earlier releases and records remain readable.

`runCheckSchema`, `calibrationSchema`, `RunCheck` and `Calibration` expose the existing canonical check model through the root and workspace entries. Optional native provenance and calibration references preserve missing/null metadata as unknown; the writer owns explicit identity evidence and per-amendment binding.


## Adapters and ingest

```ts
import { fromResearchPublication } from '@drewstone/agent-record/adapters/research-publication'

const record = fromResearchPublication(publication)
```

The adapter preserves `research-publication.events.v1` event/source references. It does not review, redact, or sanitize private logs.

```sh
agent-record-ingest RUN_DIR --out record.json --run-id RUN_ID
agent-record-ingest BUNDLE_DIR --out record.json
```

The ingester reads Runtime directories or native-session bundles without writing to them or using the network. Optional `--manifest` verifies input identity; `--native` supplies retained native captures. Anchored event IDs identify source bytes, line/JSON pointers, and items. Repeated conversion of identical inputs produces identical output. See [the ingest contract](docs/record-format.md#agent-runtime-run-directories).

Use `fromHarnessSessions` with the maintained `@tangle-network/harness-sessions` reader for Claude Code, Codex, OpenCode, Pi, Kimi, and Factory sessions. Supply recorded relationships from `@tangle-network/traces`; labels and timestamps do not establish parentage. `fromTraceSpans` and `fromStoryboardSpans` preserve their distinct upstream contracts and do not claim original capture completeness.

## Reports and historical readers

`/report` exports the research-report validator, report-option validator, report types, and LaTeX export. Authored claims and assessments remain distinct from immutable execution records.

```sh
agent-record-report REPORT.json OUTPUT.html
agent-record-report REPORT.json OUTPUT.html --source-search-endpoint /api/sources
```

The CLI uses Sandbox UI’s maintained report assets to write a self-contained interactive report and LaTeX document. Offline reports make no network requests. An optional source-search endpoint must be same-origin. The CLI preserves input-overwrite protection, private output permissions, script hashing, and its restrictive content policy. See [the report contract](docs/research-reports.md).

`/workspace`, `/assessment`, `/publication`, trace projections, and `/schemas/*` remain data contracts. Historical formats keep readers; retiring a view does not rewrite stored records. The immutable source revision/digests in [sources.json](docs/evidence/sources.json) describe archived evidence, including paths that existed in that revision.

The public `projectPartEvents(node, rows)` overload projects bounded native provider rows directly into canonical record events for live viewers. It keeps stream and attempt identity, uses the first actual producer sequence for a growing part, and leaves unavailable source anchors absent. A row sequence is not a physical source line. Retained ingestion continues to supply its real source and clipping policy through the existing seven-argument overload.

## Verification

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
PUBLIC_BASE=/agent-record/ pnpm build:example
node --test tests/example.browser.mjs
pnpm pack
```

Run these through the repository’s native gate. Preserve generated JSON schemas byte-for-byte across renderer moves. Retained-view browser proof lives with Sandbox UI; this repository keeps adapter, wire-format, ingest, CLI/report, and example consumer proof. [Consumer evidence](docs/evidence/README.md) records the checked revisions.

This repository is public. Keep captures in private evidence storage; never commit private logs, tailnet addresses, or recordings. Example checks fetch the original publication bytes at their immutable source revision and verify their recorded digests.

Code is MIT licensed. Original research papers and excerpts retain their source references and rights.

Recorded checker versions in `RunCheck.checkerNames` can carry their own optional provenance and calibration through the same canonical schemas as the current checker. Per-checker calibration accepts partial recorded metadata; the root verdict calibration still requires its existing state and stages. Omitted or null metadata stays unknown; consumers bind metadata to its checker digest and never borrow another version's source or authorship.
